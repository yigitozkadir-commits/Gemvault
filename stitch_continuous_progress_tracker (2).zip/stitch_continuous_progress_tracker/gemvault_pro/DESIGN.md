---
name: GemVault Pro
colors:
  surface: '#16130d'
  surface-dim: '#16130d'
  surface-bright: '#3d3931'
  surface-container-lowest: '#100e08'
  surface-container-low: '#1e1b15'
  surface-container: '#221f19'
  surface-container-high: '#2d2a23'
  surface-container-highest: '#38342d'
  on-surface: '#e9e1d7'
  on-surface-variant: '#d0c5b2'
  inverse-surface: '#e9e1d7'
  inverse-on-surface: '#343029'
  outline: '#99907e'
  outline-variant: '#4d4637'
  surface-tint: '#e6c364'
  primary: '#e6c364'
  on-primary: '#3d2e00'
  primary-container: '#c9a84c'
  on-primary-container: '#503d00'
  inverse-primary: '#755b00'
  secondary: '#94ceeb'
  on-secondary: '#003546'
  secondary-container: '#014f68'
  on-secondary-container: '#86c0dc'
  tertiary: '#b9c4ff'
  on-tertiary: '#1e2b66'
  tertiary-container: '#9ba8eb'
  on-tertiary-container: '#2e3b77'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe08f'
  primary-fixed-dim: '#e6c364'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#584400'
  secondary-fixed: '#bee9ff'
  secondary-fixed-dim: '#94ceeb'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#004d65'
  tertiary-fixed: '#dde1ff'
  tertiary-fixed-dim: '#b9c3ff'
  on-tertiary-fixed: '#041451'
  on-tertiary-fixed-variant: '#35437e'
  background: '#16130d'
  on-background: '#e9e1d7'
  surface-variant: '#38342d'
  bg-0: '#060608'
  bg-1: '#0c0c10'
  bg-2: '#14141a'
  bg-elev: '#1a1a22'
  ink-0: '#f4f1e8'
  ink-1: '#c8c4b8'
  ink-2: '#8a8678'
  ink-3: '#4a4842'
  gold-soft: '#8a7434'
  gold-glow: rgba(201, 168, 76, 0.2)
  rose: '#e08a8a'
  leaf: '#8ac98a'
  amber: '#e0b870'
  border: '#2a2a32'
  border-soft: '#1f1f25'
typography:
  hero:
    fontFamily: EB Garamond
    fontSize: 56px
    fontWeight: '500'
    lineHeight: '1.15'
  headline-3xl:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.15'
  headline-2xl:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '500'
    lineHeight: '1.15'
  headline-xl:
    fontFamily: EB Garamond
    fontSize: 22px
    fontWeight: '500'
    lineHeight: '1.35'
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.55'
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.55'
  body-sm:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.55'
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.55'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  sp-1: 4px
  sp-2: 8px
  sp-3: 12px
  sp-4: 16px
  sp-5: 24px
  sp-6: 32px
  sp-7: 48px
  sp-8: 64px
  sp-9: 96px
  header-h: 64px
  sidebar-w: 280px
  max-content: 1280px
---

# GemVault Pro — Design System

## 🎨 DESIGN TOKENS

```css
:root {
  /* === RENKLER === */
  --bg-0:       #060608;     /* en koyu zemin */
  --bg-1:       #0c0c10;     /* kart zemin */
  --bg-2:       #14141a;     /* hover, secondary */
  --bg-elev:    #1a1a22;     /* modal, popover */

  --ink-0:      #f4f1e8;     /* ana metin */
  --ink-1:      #c8c4b8;     /* secondary text */
  --ink-2:      #8a8678;     /* muted */
  --ink-3:      #4a4842;     /* disabled */

  --gold:       #c9a84c;     /* primary accent */
  --gold-soft:  #8a7434;     /* gold hover dark */
  --gold-glow:  #c9a84c33;   /* gold w/ alpha */

  --blue:       #7eb8d4;     /* secondary accent */
  --blue-soft:  #5d8ca3;
  --rose:       #e08a8a;     /* danger */
  --leaf:       #8ac98a;     /* success */
  --amber:      #e0b870;     /* warning */

  --border:     #2a2a32;
  --border-soft:#1f1f25;

  /* === TİPOGRAFİ === */
  --font-serif: 'Cormorant Garamond', Georgia, serif;
  --font-sans:  'Instrument Sans', system-ui, -apple-system, sans-serif;
  --font-mono:  'DM Mono', 'Fira Code', Consolas, monospace;

  --fs-xs:   12px;
  --fs-sm:   14px;
  --fs-md:   16px;
  --fs-lg:   18px;
  --fs-xl:   22px;
  --fs-2xl:  28px;
  --fs-3xl:  36px;
  --fs-hero: 56px;

  --lh-tight: 1.15;
  --lh-snug:  1.35;
  --lh-base:  1.55;
  --lh-loose: 1.75;

  /* === SPACING === */
  --sp-1: 4px;
  --sp-2: 8px;
  --sp-3: 12px;
  --sp-4: 16px;
  --sp-5: 24px;
  --sp-6: 32px;
  --sp-7: 48px;
  --sp-8: 64px;
  --sp-9: 96px;

  /* === RADIUS === */
  --r-sm:   6px;
  --r-md:   12px;
  --r-lg:   20px;
  --r-pill: 9999px;

  /* === SHADOW === */
  --sh-1: 0 1px 2px #00000033;
  --sh-2: 0 4px 12px #00000055;
  --sh-3: 0 12px 32px #00000077;
  --sh-glow-gold: 0 0 24px var(--gold-glow);

  /* === MOTION === */
  --dur-fast: 120ms;
  --dur-med:  220ms;
  --dur-slow: 360ms;
  --ease:     cubic-bezier(.2,.7,.2,1);

  /* === LAYOUT === */
  --header-h:  64px;
  --sidebar-w: 280px;
  --content-max: 1280px;
}
```

## 🧩 GLOBAL COMPONENTS

### Header
- Sticky, 64px height, blur backdrop, gold accent border-bottom 1px.
- Logo: "GemVault Pro" with ◈ icon.
- Nav: Gems, Creator, Radar, Favorites, Collections.
- Actions: Search, Notifications, Settings, Avatar.

### Sidebar
- Fixed 280px (Desktop), Drawer (Mobile).
- Search input.
- Category list with counts.

### Buttons
- Primary (Gold), Secondary (Dark), Ghost, Danger (Rose).

### Gem Card
- Header (Icon, Category Chip, Fav Button).
- Body (Title, Description).
- Footer (Meta info: tokens/languages, Primary CTA).
