# GemVault Pro — STITCH FRONTEND MASTER PROMPT

> **TEK PROMPTLA TÜM FRONTEND'İ KURMAK İÇİN GOOGLE STITCH'E VERİLECEK MASTER BRIEF**
>
> Stitch normalde 5 sayfa sonra bağlamı kaybediyor ve tutarsız frontend üretiyor. Bu doküman bu sorunu **3 katmanlı çözüm** ile aşıyor:
> 1. **Single Source of Truth (SSOT) Design System Tokens** — Stitch her sayfayı bu token tablosuna referans vererek üretir; renk/font/spacing **asla** drift etmez.
> 2. **Sayfa-bazlı atomik brief'ler** — her sayfa ayrı ayrı tanımlı ama hepsi aynı header'da aynı global kurallara bağlı.
> 3. **Cross-page consistency contract** — Stitch'in her oluşturduğu sayfanın başında **mutlaka** uyması gereken global checklist var; çıktının ilk satırı bu checklist'i yeniden onaylar.
>
> **Stitch'te kullanım:** Bu dosyanın tamamını **tek mesaj** olarak Stitch'e yapıştır. Stitch sırayla her sayfayı üretecek. Çıktıyı ZIP olarak indirip repo'na `apps/web/src/views/` altına atacaksın.

---

## 🔒 GLOBAL CONSISTENCY CONTRACT (HER SAYFADA UYULACAK)

> Stitch, her sayfayı üretmeden önce bu kontratı **HTML yorum bloğu** olarak çıktının en başına yaz. Bu, kendi-doğrulama mekanizmasıdır.

```html
<!--
GEMVAULT CONSISTENCY CONTRACT v1.0
================================
[X] Renk paleti: --bg #060608 / --gold #c9a84c / --ink #f4f1e8 / --blue #7eb8d4
[X] Font: Cormorant Garamond (h1-h2), Instrument Sans (gövde), DM Mono (kod)
[X] Spacing: 4/8/12/16/24/32/48/64 px scale (asla başka değer)
[X] Border radius: 6 (chip), 12 (card), 20 (modal), 9999 (pill)
[X] Header: Sticky, 64px height, blur backdrop, gold accent border-bottom 1px
[X] Sidebar: 280px sabit (desktop), drawer (mobile)
[X] Tüm interaktif elementlerde focus ring: 2px solid var(--gold) outline-offset 2px
[X] prefers-reduced-motion query mevcut
[X] dir="rtl" desteği logical properties ile
[X] Tüm sayfalar PWA shell içinde çalışır — global header/sidebar component ortak
-->
```

---

## 🎨 DESIGN TOKENS (SSOT — tek kaynak)

Stitch, her sayfada bu CSS değişkenlerini **AYNI** tanımlayacak. Token isimleri değişmeyecek.

```css
:root {
  /* === RENKLER === */
  --bg-0:       #060608;     /* en koyu zemin */
  --bg-1:       #0c0c10;     /* kart zemin */
  --bg-2:       #14141a;     /* hover, secondary */
  --bg-elev:    #1a1a22;     /* modal, popover */

  --ink-0:      #f4f1e8;     /* ana metin */
  --ink-1:      #c8c4b8;     /* secondary text */
  --ink-2:      #8a8678;     /* muted */
  --ink-3:      #4a4842;     /* disabled */

  --gold:       #c9a84c;     /* primary accent */
  --gold-soft:  #8a7434;     /* gold hover dark */
  --gold-glow:  #c9a84c33;   /* gold w/ alpha */

  --blue:       #7eb8d4;     /* secondary accent */
  --blue-soft:  #5d8ca3;
  --rose:       #e08a8a;     /* danger */
  --leaf:       #8ac98a;     /* success */
  --amber:      #e0b870;     /* warning */

  --border:     #2a2a32;
  --border-soft:#1f1f25;

  /* === TİPOGRAFİ === */
  --font-serif: 'Cormorant Garamond', Georgia, serif;
  --font-sans:  'Instrument Sans', system-ui, -apple-system, sans-serif;
  --font-mono:  'DM Mono', 'Fira Code', Consolas, monospace;

  --fs-xs:   12px;
  --fs-sm:   14px;
  --fs-md:   16px;
  --fs-lg:   18px;
  --fs-xl:   22px;
  --fs-2xl:  28px;
  --fs-3xl:  36px;
  --fs-hero: 56px;

  --lh-tight: 1.15;
  --lh-snug:  1.35;
  --lh-base:  1.55;
  --lh-loose: 1.75;

  /* === SPACING === */
  --sp-1: 4px;
  --sp-2: 8px;
  --sp-3: 12px;
  --sp-4: 16px;
  --sp-5: 24px;
  --sp-6: 32px;
  --sp-7: 48px;
  --sp-8: 64px;
  --sp-9: 96px;

  /* === RADIUS === */
  --r-sm:   6px;
  --r-md:   12px;
  --r-lg:   20px;
  --r-pill: 9999px;

  /* === SHADOW === */
  --sh-1: 0 1px 2px #00000033;
  --sh-2: 0 4px 12px #00000055;
  --sh-3: 0 12px 32px #00000077;
  --sh-glow-gold: 0 0 24px var(--gold-glow);

  /* === MOTION === */
  --dur-fast: 120ms;
  --dur-med:  220ms;
  --dur-slow: 360ms;
  --ease:     cubic-bezier(.2,.7,.2,1);

  /* === LAYOUT === */
  --header-h:  64px;
  --sidebar-w: 280px;
  --content-max: 1280px;
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
}

/* Focus ring — global */
:focus-visible {
  outline: 2px solid var(--gold);
  outline-offset: 2px;
  border-radius: var(--r-sm);
}
```

---

## 🧩 GLOBAL COMPONENT KÜTÜPHANESİ (her sayfada AYNI kod)

Stitch, aşağıdaki componentleri **her sayfada birebir aynı** üretmeli. Markup'ta CSS class isimleri değişmeyecek.

### Header
```html
<header class="gv-header" role="banner">
  <a href="/" class="gv-logo">
    <span class="gv-logo-mark">◈</span>
    <span class="gv-logo-text">GemVault <em>Pro</em></span>
  </a>
  <nav class="gv-nav" aria-label="Ana menü">
    <a href="/gems" class="gv-nav-link">Gemler</a>
    <a href="/creator" class="gv-nav-link">Üretici</a>
    <a href="/radar" class="gv-nav-link">Radar</a>
    <a href="/favorites" class="gv-nav-link">Favoriler</a>
    <a href="/collections" class="gv-nav-link">Koleksiyonlar</a>
  </nav>
  <div class="gv-header-actions">
    <button class="gv-icon-btn" aria-label="Arama (⌘K)">🔍</button>
    <button class="gv-icon-btn" aria-label="Bildirimler">🔔</button>
    <button class="gv-icon-btn" aria-label="Ayarlar">⚙</button>
    <button class="gv-avatar" aria-label="Profil">U</button>
  </div>
</header>
```

### Sidebar
```html
<aside class="gv-sidebar" aria-label="Kategoriler">
  <div class="gv-search">
    <input type="search" placeholder="Gem ara… (⌘K)" class="gv-input">
  </div>
  <div class="gv-cat-list">
    <button class="gv-cat-btn active">Tümü <span class="gv-cat-count">735</span></button>
    <button class="gv-cat-btn">Strateji <span class="gv-cat-count">52</span></button>
    <!-- 18 kategori -->
  </div>
  <div class="gv-sidebar-footer">
    <button class="gv-btn gv-btn-ghost">Filtreler</button>
  </div>
</aside>
```

### Buton Stilleri
```css
.gv-btn { padding: 10px 18px; border-radius: var(--r-sm); font: 500 var(--fs-sm)/1 var(--font-sans); border: 1px solid transparent; cursor: pointer; transition: all var(--dur-fast) var(--ease); }
.gv-btn-primary { background: var(--gold); color: var(--bg-0); }
.gv-btn-primary:hover { background: var(--gold-soft); }
.gv-btn-secondary { background: var(--bg-2); color: var(--ink-0); border-color: var(--border); }
.gv-btn-ghost { background: transparent; color: var(--ink-1); }
.gv-btn-ghost:hover { background: var(--bg-2); color: var(--ink-0); }
.gv-btn-danger { background: var(--rose); color: var(--bg-0); }
```

### Gem Card (en kritik — drift olmamalı)
```html
<article class="gv-gem-card" tabindex="0">
  <header class="gv-gem-head">
    <span class="gv-gem-icon" aria-hidden="true">⌬</span>
    <span class="gv-gem-cat-chip">Strateji</span>
    <button class="gv-fav-btn" aria-label="Favorilere ekle">♡</button>
  </header>
  <h3 class="gv-gem-title">Stratejik Pazar Analisti</h3>
  <p class="gv-gem-desc">Detaylı pazar analizi yapan, rakip benchmarking ve SWOT üreten uzman persona.</p>
  <footer class="gv-gem-foot">
    <span class="gv-gem-meta">12 token · TR/EN</span>
    <button class="gv-btn gv-btn-primary">Kullan</button>
  </footer>
</article>
```

---

## 📐 ÜRETİLECEK SAYFALAR (TOPLAM 12)

Stitch sırayla bu 12 sayfayı üretecek. **Her sayfa başında consistency contract'ı yeniden doğrula.** Her sayfa tek HTML dosyası, mevcut global header+sidebar+token CSS'i içerir.

---

### 🟦 SAYFA 1 — `index.html` (Landing / Hero)

**Amaç:** Uygulama açıldığında karşılayan görsel olarak çarpıcı landing.

**Bileşenler:**
- Hero: H1 "Gemini için 735 Premium Gem" (Cormorant 56px), alt başlık (Instrument Sans 18px ink-1).
- 4 istatistik kartı: 735 Gem · 18 Kategori · 12 Dil · Offline ✓.
- "Keşfet" CTA (gold) + "Demo izle" (ghost).
- Aşağı kaydırıldıkça: 3 sütunlu feature grid (AI Arama, Radar, Molo).
- Gem preview carousel — 6 öne çıkan gem.
- Final CTA banner: "Hesabınızı oluşturun" + email input.

**Layout:** Header + tam genişlik içerik (sidebar yok bu sayfada). Footer'da telif + sosyal.

**Animasyonlar:** Hero text fade-up 600ms ease, statlar staggered fade-in 100ms aralıkla.

---

### 🟦 SAYFA 2 — `gems.html` (Ana Gem Kütüphanesi)

**Amaç:** Ana çalışma sayfası. Sol sidebar (kategoriler), orta sütun (gem grid), sağ panel (seçili gem detayı).

**Bileşenler:**
- Üst arama bar (sticky): semantik arama input, view toggle (grid/list), sort dropdown.
- Aktif filtre chip'leri (kapatma butonlu).
- Gem grid: 3 sütun (desktop), 2 (tablet), 1 (mobile). Yukarıdaki `gv-gem-card` markup'ı.
- Sayfa sonunda "Daha fazla yükle" — infinite scroll trigger.
- Sağ detay paneli (kapatılabilir): seçili gem'in tam metni, "Kopyala", "Favorilere ekle", "Koleksiyona ekle", "Düzenle (Pro)" butonları, dolu/boş [PLACEHOLDER]'lar için inline form.

**Klavye:** ⌘K arama, j/k ile gemler arası gezinme, Enter ile aç, f ile favori.

---

### 🟦 SAYFA 3 — `creator.html` (Gem Üretici)

**Amaç:** Kullanıcı amaç/role girer, AI custom gem üretir.

**Bileşenler:**
- Sol: Form (3 adım wizard) — "Persona", "Davranış", "Stil & Kısıtlar".
- Sağ: Canlı önizleme — üretilen system prompt'u monospace ile.
- Alt: "Üret", "Kaydet", "Test Et (Molo'da)" butonları.
- History sidebar: önceki üretilenler (zaman damgalı).

**Tasarım vurgu:** Sağ önizleme paneli `--bg-elev` zeminli, gold accent border-left 2px.

---

### 🟦 SAYFA 4 — `radar.html` (AI Haber Radarı)

**Amaç:** RSS aggregator — OpenAI, Anthropic, DeepMind, Google AI blog feed'leri.

**Bileşenler:**
- Üst: kaynak filtre chip'leri (multi-select).
- Tarih aralığı: "Bugün / Bu hafta / Bu ay / Tümü".
- Feed kartları: kaynak logo + başlık + 2 satır özet + tarih + "Tam metin" link + "Molo ile özetlet" butonu.
- Sağ sticky panel: "AI Haftalık Özet" (Pro feature — paywall'lı blur efekti free kullanıcıda).

**Loading state:** 6 adet skeleton kart, shimmer animasyonu.

---

### 🟦 SAYFA 5 — `favorites.html` (Favoriler)

**Amaç:** Kullanıcının ♡ ile işaretlediği gemler.

**Bileşenler:**
- Boş state (mutlaka tasarla): büyük 🤍 ikon + "Henüz favori eklemedin" + "Keşfet" CTA + 4 öneri kartı.
- Dolu state: aynı gem grid, ama her kartta üst-sağda "kaldır" X butonu.
- Bulk actions toolbar (en az 1 seçili): "Koleksiyona Taşı", "Export", "Tümünü Kaldır".
- Drag & drop ile koleksiyonlara taşıma.

---

### 🟦 SAYFA 6 — `collections.html` (Koleksiyonlar)

**Amaç:** Kullanıcı tanımlı klasörler.

**Bileşenler:**
- Üst: "+ Yeni Koleksiyon" butonu.
- Grid: koleksiyon kartları — emoji/icon + isim + gem sayısı + renk şeridi (üst kenar 4px).
- Hover: kart hafifçe yükselir (--sh-2), gold border belirir.
- Karta tıklayınca: detay modal — içindeki gemler liste, reorder (drag handles), paylaş URL (Pro).
- Boş state: "Bu koleksiyonu kolaylaştırmak için template seç" — "İş", "Yazılım", "İçerik", "Eğitim" hazır şablonları.

---

### 🟦 SAYFA 7 — `molo.html` (Molo AI Asistan Chat)

**Amaç:** Köstebek asistanla full-page sohbet.

**Bileşenler:**
- Üst bant: Molo avatar (köstebek illüstrasyon) + "Çevrimiçi" badge + "Sesli mod" toggle.
- Mesaj alanı: user (sağ, --bg-2) + Molo (sol, --bg-1 + gold left border).
- Markdown render: kod blokları, listeler, başlıklar.
- Mesaj action'ları: 📋 kopyala, 🔁 tekrar, 👍/👎 feedback.
- Input area (sticky bottom): textarea (auto-grow), 🎤 mic, 📎 dosya (gem context), Enter gönder, Shift+Enter newline.
- Function call cards: Molo "Bu gem'i favorilere ekleyim mi?" → onay/red butonları.
- Sol drawer: konuşma geçmişi (PostHog yerine local).

**Streaming:** Cevap kelime kelime akar, son kelimede gold pulse animasyonu.

---

### 🟦 SAYFA 8 — `settings.html` (Ayarlar)

**Amaç:** Tüm tercihler tek sayfada, sol nav + sağ panel.

**Bileşenler:**
- Sol nav (sekmeler): Hesap · Görünüm · Dil · Bildirimler · Senkronizasyon · Gizlilik · Abonelik · Hakkında.
- Sağ panel her sekme için form:
  - **Görünüm:** Tema seçici (Karanlık / Açık / Sistem), 8 vurgu rengi swatch, font boyutu slider, animasyon toggle.
  - **Dil:** TR/EN/DE/ES/AR — bayrak ikonlu radio kartları.
  - **Senkronizasyon:** durum (yeşil/sarı/kırmızı LED), son sync, "Şimdi sync et", cihaz listesi.
  - **Abonelik:** mevcut plan kartı, "Pro'ya geç" CTA, billing portal link.
  - **Gizlilik:** analytics opt-in toggle, "Verilerimi indir", "Hesabımı sil".

**Tasarım:** Form alanları arası 24px gap, her bölüm başlığı Cormorant 22px gold.

---

### 🟦 SAYFA 9 — `pricing.html` (Paywall / Fiyatlandırma)

**Amaç:** Free vs Pro vs Lifetime karşılaştırma.

**Bileşenler:**
- 3 kart yan yana — orta (Pro) "En Popüler" badge'li, hafifçe büyütülmüş.
- Her kartta: plan adı, fiyat (büyük), feature listesi (✓ gold / — muted), CTA buton.
- Aylık/Yıllık toggle (yıllıkta "%33 indirim" rozeti).
- Karşılaştırma tablosu (alt) — tam feature matrisi.
- FAQ accordion — 6 soru (iade, vergi, plan değişimi, vs).
- Trust badges: "30 gün iade" · "Stripe güvenli ödeme" · "İstediğin zaman iptal".

---

### 🟦 SAYFA 10 — `auth.html` (Giriş / Kayıt)

**Amaç:** Magic link + OAuth.

**Bileşenler:**
- Ortalanmış kart (max 420px).
- Logo + "GemVault'a hoş geldin" başlık.
- E-posta input + "Bana sihirli link gönder" buton (--gold).
- "veya" ayırıcısı.
- "Google ile devam et" + "Apple ile devam et" butonları (provider logoları).
- Alt link: "Devam ederek Kullanım Şartları ve Gizlilik Politikası'nı kabul ediyorsun."
- Magic link gönderildi state: "✉ E-postanı kontrol et" + "Tekrar gönder (30s)" countdown.

---

### 🟦 SAYFA 11 — `onboarding.html` (İlk Açılış Tour)

**Amaç:** 3 adımlık tour + ilgi seçimi.

**Bileşenler:**
- Üst progress bar (3 nokta).
- **Step 1:** Full-screen illüstrasyon + "735 hazır Gem seni bekliyor" + "İleri".
- **Step 2:** "Hangi alanlar ilgini çekiyor?" — 18 kategori chip'i (multi-select), en az 3 seç.
- **Step 3:** "Molo seninle tanışmak istiyor" — Molo karakteri + "Sohbete başla" / "Atla".
- Her step'te sağ üstte "Atla" link.

---

### 🟦 SAYFA 12 — `error-404.html` + `offline.html` + `loading.html`

**Amaç:** Edge case sayfaları, ama design system'le tutarlı.

- **404:** Büyük "404" Cormorant 120px gold gradient + "Aradığın gem burada değil" + "Ana sayfa" + "Tüm gemler" butonları.
- **Offline:** Eski Polaroid stil illüstrasyon + "Çevrimdışısın ama 735 gem hala kullanılabilir" + cache'lenen kategoriler.
- **Loading skeleton:** Tüm grid/liste yapıları için skeleton'lar — shimmer animasyonu (`linear-gradient` + `background-position` keyframes).

---

## 📱 RESPONSIVE KURALLAR (HER SAYFADA)

| Breakpoint | İsim | Kural |
|---|---|---|
| ≥1280px | xl | Tam sidebar (280px) + 3 sütun grid + sağ detay panel |
| 1024-1279 | lg | Sidebar 240px, 2 sütun grid, detay panel modal'a düşer |
| 768-1023 | md | Sidebar drawer, 2 sütun grid |
| <768 | sm | Sidebar bottom-sheet, 1 sütun, header'da hamburger |

Mobile-specific:
- Bottom tab bar (5 ikon: Gems / Creator / Radar / Favorites / Settings).
- Header avatarı, hamburger'a dönüşür.
- Modallar full-screen.
- Swipe-to-dismiss drawer'lar.

---

## ♿ ERİŞİLEBİLİRLİK ZORUNLULUKLAR (HER SAYFADA)

- Her sayfanın `<title>` ve `<meta name="description">`'ı.
- `<main>`, `<nav>`, `<aside>`, `<header>`, `<footer>` semantic landmark'lar.
- Tüm form inputları `<label>` veya `aria-label` ile bağlı.
- Modal'lar: `role="dialog"`, `aria-modal="true"`, focus trap, Esc kapatır.
- Toast'lar: `role="status"` + `aria-live="polite"`.
- Color-only bilgi yasak — her renk + ikon/metin ile pekiştirilmeli.
- Tüm görsellerde anlamlı `alt` (dekoratifse `alt=""`).
- Skip link: ilk Tab'da "Ana içeriğe atla" görünür.

---

## 🌐 DİL & RTL

- HTML kök: `<html lang="tr" dir="ltr">` — dinamik değişir.
- AR seçilirse `dir="rtl"` + tüm `margin-left` → `margin-inline-start`.
- Metin örnekleri için Lorem ipsum yerine **gerçek Türkçe** içerik kullan (Stitch sık sık Lipsum koyar — yasak).
- Sayfa içeriklerinde i18n key referansları yorum olarak: `<!-- i18n: gems.title -->Gemler<!-- /i18n -->`.

---

## 🚀 STITCH'E TALİMAT — TAM YÜRÜTÜM PROTOKOLÜ

> **Stitch, aşağıdaki adımları sırayla uygula. Her sayfa için ayrı dosya üret. Hiçbir sayfada token isimlerini veya global componentleri değiştirme.**

1. **Çıktı formatı:** Tek bir ZIP'in içeriği gibi düşün — her sayfa kendi `.html` dosyası (12 dosya) + bir tane `tokens.css` + bir tane `components.css` + bir tane `global.js`.
2. **Her sayfa şu sırayla:** ① Consistency Contract yorumu ② `<head>` (linked CSS/JS) ③ `<body>` içinde header + (sidebar varsa) + main + footer.
3. **CSS:** `tokens.css` ve `components.css` her sayfada `<link>` ile çağrılır — inline yazma.
4. **Lipsum yasak.** Gerçek Türkçe içerik üret (GemVault Pro bağlamı).
5. **Drift kontrolü:** Her 3 sayfada bir kez geri dön — son ürettiklerinin renk/font/spacing'i ilk sayfayla eşleşiyor mu? Eşleşmiyorsa düzelt.
6. **Final teslimat:** Sonda bir `README.md` üret — dosya listesi, kurulum, repo'ya nasıl entegre edileceği.
7. **No JS framework.** Vanilla HTML/CSS/minimal JS — sonra Vite ESM'e migrate edilecek.
8. **Görseller:** İllüstrasyonlar için SVG inline kullan (Heroicons / Lucide tarzı, ama her sayfada aynı stroke-width: 1.5, aynı stroke-linecap: round).

---

## 🧪 OUTPUT QUALITY CHECKLIST (Stitch kendi-doğrulama)

Her sayfa üretildikten sonra Stitch şu kontrolleri yapsın, başarısız olursa düzeltsin:

- [ ] Token isimleri SSOT listesinden bir karakter bile sapmıyor mu?
- [ ] Header markup'ı önceki sayfayla **identical** mi?
- [ ] Sidebar markup'ı önceki sayfayla **identical** mi (sayfa için gerekiyorsa)?
- [ ] Yeni renk eklenmedi (palette dışı) mi?
- [ ] Yeni spacing değeri (4/8/12/16/24/32/48/64 dışı) yok mu?
- [ ] Tüm interactive elementlerin focus state'i tanımlı mı?
- [ ] Sayfa H1'i tek mi (multiple H1 yok)?
- [ ] Mobile breakpoint'te layout kırılıyor mu (Stitch preview'da test)?
- [ ] `aria-*` attribute'ları semantic ve doğru mu?
- [ ] Lipsum yok, Türkçe gerçek içerik var mı?

---

## 🎁 BONUS — STITCH'İN BAĞLAM KAYBINI ÖNLEYEN "HATIRLATICI" SİSTEMİ

Stitch 5+ sayfa sonra bağlamı kaybediyor. Çözüm: **Her yeni sayfa istenmeden önce kısa "anchor reminder" gönder**:

> "🔁 ANCHOR REMINDER — Sayfa #N'i üretmeden önce: ① Token tablonu açık tut (--bg-0 #060608, --gold #c9a84c). ② Önceki sayfanın header HTML'ini kopyala-yapıştır (değiştirme). ③ Sidebar var/yok kararı bu sayfa için: [VAR/YOK]. ④ Bu sayfanın amacı: [TEK CÜMLE]. Şimdi üret."

Bu hatırlatıcıyı, master prompt'tan sonra her sayfa için ayrı mesajla Stitch'e gönder. Toplam **13 mesaj** (1 master + 12 anchor reminder) ile tam 12 sayfa tutarlı şekilde üretilir.

---

## 🛠️ STITCH ÇIKTISI → REPO ENTEGRASYONU (ZIP açıldıktan sonra)

Stitch ZIP'i indirip repo'na atıktan sonra:

```
gemvault-pro/
└── apps/
    └── web/
        └── src/
            ├── views/               # ← Stitch HTML'leri buraya
            │   ├── index.html
            │   ├── gems.html
            │   ├── creator.html
            │   ├── radar.html
            │   ├── favorites.html
            │   ├── collections.html
            │   ├── molo.html
            │   ├── settings.html
            │   ├── pricing.html
            │   ├── auth.html
            │   ├── onboarding.html
            │   ├── error-404.html
            │   ├── offline.html
            │   └── loading.html
            ├── styles/
            │   ├── tokens.css       # ← Stitch'ten
            │   └── components.css   # ← Stitch'ten
            └── scripts/
                └── global.js        # ← Stitch'ten
```

Sonra Claude Code'a şu prompt'u ver:

> "`apps/web/src/views/` altındaki 12 HTML dosyasını Vite + Vanilla ESM mimarisine çevir. Her sayfa için bir route component'i çıkar, ortak header/sidebar'ı Web Component'e dönüştür, business logic'i `packages/core` ve `packages/ui`'a böl. Mevcut v5.2 monolitik dosyadaki tüm fonksiyonelliği (735 gem datası, search, favorites, molo, radar) yeni view'lara wire et. Test ekle. CHANGELOG güncelle."

---

## 📌 SON KURAL

Stitch'in bağlam kaybını **gözlemlersen** (örn. yeni bir renk üretti, font değişti, header yapısı bozuldu): **DUR**, son düzgün sayfayı kopyala, "🔁 ANCHOR REMINDER" mesajını yeniden gönder, problem sayfayı **tek başına yeniden üretmesini iste**. Bu disiplin sayesinde 12 sayfa boyunca drift sıfıra iner.

**BU PROMPT'UN TAMAMINI TEK MESAJ OLARAK STITCH'E YAPIŞTIR. SONRA 12 ANCHOR REMINDER GÖNDER. BİTTİ.**
